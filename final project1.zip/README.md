# 🌾 FarmIntel – Smart Farming & Crop Intelligence System

Full-stack application: **HTML, CSS, Bootstrap, JavaScript** (frontend) + **Python Flask** (backend) + **MySQL** (XAMPP). Database name: `farm_intel`.

## Features

- **Farmer Panel**: Login/Signup (bilingual notes EN + Gujarati), Crops (view, search, filter), Government Schemes, Farm Store (cart, checkout, invoice, order history), Financial Analysis (expense/income/profit).
- **Admin Panel**: Login/Signup, Crop Management (add/edit/delete/activate), Government Schemes (CRUD), Farm Store products (CRUD).
- **Strict role separation**: Farmer and Admin routes and navbars are separate.

## Setup

### 1. Database (XAMPP MySQL)

1. Start Apache and MySQL in XAMPP.
2. Create database: `CREATE DATABASE farm_intel;`
3. Import schema:
   ```bash
   mysql -u root -p farm_intel < database/schema.sql
   ```
   Or open `database/schema.sql` in phpMyAdmin and run it.

### 2. Python

```bash
cd "tarun project"
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Config

Edit `config.py` if needed (MySQL user/password). Default: `root` with no password.

### 4. Run

```bash
python app.py
```

Open: **Farmer** → http://127.0.0.1:5001/farmer/login  
**Admin** → http://127.0.0.1:5001/admin/login  

## Project Structure

```
├── app.py              # Flask app entry
├── config.py           # DB and upload config
├── db.py               # MySQL init
├── auth_utils.py       # Password hash, farmer_required, admin_required
├── requirements.txt
├── database/
│   └── schema.sql      # MySQL tables
├── routes/
│   ├── auth.py         # Farmer/Admin login & signup (POST)
│   ├── farmer.py       # Farmer login/signup pages (GET), dashboard
│   ├── admin_routes.py # Admin login/signup pages (GET), dashboard
│   ├── crops.py        # Crops list/detail (farmer), CRUD (admin)
│   ├── schemes.py      # Schemes list (farmer), CRUD (admin)
│   ├── store.py        # Store, cart, checkout, orders (farmer); products CRUD (admin)
│   └── financial.py    # Financial analysis (farmer)
├── templates/
│   ├── base.html
│   ├── farmer/         # Login, signup, dashboard, crops, schemes, store, cart, checkout, invoice, orders, financial
│   └── admin/          # Login, signup, dashboard, crops, schemes, products
└── static/
    └── uploads/        # crops/, products/ (images)
```

## Navbars

- **Farmer**: Dashboard, Crops, Government Schemes, Farm Store, Cart, Orders, Financial Analysis, Logout.
- **Admin**: Dashboard, Crop Management, Government Schemes, Farm Store (Products), Logout.

## User Flow (Farmer)

Login → Dashboard → Crops (view/detail) → Farm Store (browse, add to cart) → Checkout → Invoice → Financial Analysis (add record, view profit/loss).
